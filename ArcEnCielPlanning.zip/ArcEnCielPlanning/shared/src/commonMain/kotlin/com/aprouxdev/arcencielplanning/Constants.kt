package com.aprouxdev.arcencielplanning

const val SERVER_PORT = 8080